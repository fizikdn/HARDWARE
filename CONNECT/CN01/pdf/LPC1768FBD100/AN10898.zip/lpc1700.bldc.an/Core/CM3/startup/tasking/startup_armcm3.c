/*
 * TASKING CMSIS startup code.
 *
 * This file is empty as:
 * - the startup code is part of libc.
 * - the vector table is built using .lsl files through the linker.
 */
