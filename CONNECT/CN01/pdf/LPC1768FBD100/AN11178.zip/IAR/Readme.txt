/*************************************************************************
 * @file		Readme.txt
 * @brief		Description of the LPC17xx MP3 Player example for IAR EWARM
 *                      using the Code Red RDB1768 board.
 * @version		1.0
 * @date		09. Mar. 2012
 * @author		NXP MCU SW Application Team
 *
 * Description:
 * This solution takes full advantage of LPC1700's high performance and rich
 * peripherals to makes it possible to playback MP3 files.
 * USB Host stack and file system are also integrated to support access to files
 * in SDC/MMC card and USB flash disk
 *
 * Source:
 *   - Helix MP3 Decoder: by RealNetworks, https://datatype.helixcommunity.org/Mp3dec
 *       It has been ported to thumb-2 by NXP Semiconductors.
 *   - FatFs: by ChaN, http://elm-chan.org/fsw/ff/00index_e.html
 *       It has been ported to LPC1700 to access SDC/SDHC/MMC/USB
 *   - USBHosteLite: by NXP Semiconductors and OnChip Technologies, http://ics.nxp.com/support/software/usb.host.msc/
 *   - main program: by NXP Semiconductors
 *
 *************************************************************************
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * products. This software is supplied "AS IS" without any warranties.
 * NXP Semiconductors assumes no responsibility or liability for the
 * use of the software, conveys no license or title under any patent,
 * copyright, or mask work right to the product. NXP Semiconductors
 * reserves the right to make changes in the software without
 * notification. NXP Semiconductors also make no representation or
 * warranty that such application will be suitable for the specified
 * use without further testing or modification.
 ************************************************************************/

@Example description:
	Purpose:
		This example describes how to read MP3 files from a USB flash drive and a SD/MMC card
		and how to decode these files in software & playback the audio by using the
		NXP UDA1380 audio codec via I2S.
	Process:
		With default settings, at least a USB flash drive should be connected to the USB port
		of the RDB1768 board. Optionally, a SD/MMC card may be inserted into the micro SD slot
		(located underneath the LCD of the RDB1768 board). At least one of these storage devices
		needs to have MP3 files copied to its root directory. If USB support is not required,
		the need for connecting a USB flash drive can be removed by disabling USB support.
		This can be done by opening the file "Storage.h", and remove/comment-out the lien that sais:
		#define SUPPORT_USB
        
		A headphone should be connected to the HEADPHONE OUT jack plug.
		
		Optionally, the COM port of the RDB1768 may be connected to a computer's serial port.
		By opening a terminal (PuTTY, TeraTerm, HyperTerminal, ...) to the computer's serial port,
		using settings 115200 8N1, more information on the MP3 player can be seen.
		
		The LPC1768 uses the FatFs filesystem library for browsing files on SD/MMC card and USB flash drive.
		The USBHostLite stack is used for the LPC1768 to function as a USB Host and get data from a
		Mass Storage Device (MSD).
		
		The LPC1768 uses the I2C bus to configure the Audio codec UDA1380. It uses the I2S bus to transfer
		audio data between the codec and the microcontroller.

		LPC1768 I2C controller configuration:
			- 44.1 kHz;
			- 16 bits
			- Stereo;
			- TX master;

		After power-on, the device will search for connected media, and search for MP3 files on the
		discovered devices. All files found will be listed on the LCD in 8.3 SFN format and will be
		listed on the serial port in both 8.3 SFN and LFN format.
		
		By default, it will directly start playing the first listed file. The file that is currently
		beeing played will be colored in GREEN. By pressing the UP and DOWN	buttons of the joystick,
		the RED cursor can be moved. By pressing the CENTER button of the joystick, the player will
		start playing the file located at the cursor.

		If a terminal is connected to the RDB1768's COM port, the number preceding the filename can
		be entered. After hitting ENTER in the terminal, the song with that number will be played.
				
	Build and test enviroment:
		This application was built using IAR EWARM v6.30.4.3295
                Hardware: code_red RDB1768v2.
                