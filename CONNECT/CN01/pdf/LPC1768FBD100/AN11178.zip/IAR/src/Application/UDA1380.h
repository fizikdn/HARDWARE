/* Header file for UDA1380 driver */

#ifndef UDA1380_H

/* Public functions */
void  UDA1380_Init(void);
void UDA1380_MasterVolCtrl (uint8_t left, uint8_t right);

#endif
