#include "lpc17xx_uart.h"

int (__write)(int Handle, const unsigned char *Buf, size_t BufSize) 
{ 
  int i;
  
  for(i=0;i<BufSize;i++)
  {
    UART_PutChar(Buf[i]);
  }
  
  return BufSize;
} 