#ifndef __LPC17XX_TIMER_H 
#define __LPC17XX_TIMER_H

#include "lpc_types.h"

extern void init_timer(UNS_32 timerInterval );


#endif /* end __LPC17XX_TIMER_H */
/*****************************************************************************
**                            End Of File
******************************************************************************/
