/*****************************************************************************
 * callbacks.h 
 *
 * Project: LPC17xx Capacitive Touch Sensing demo program
 *
 * Description:
 *   Header file for the Led module 
 *
 *----------------------------------------------------------------------------
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * products. This software is supplied "AS IS" without any warranties.
 * NXP Semiconductors assumes no responsibility or liability for the
 * use of the software, conveys no license or title under any patent,
 * copyright, or mask work right to the product. NXP Semiconductors
 * reserves the right to make changes in the software without
 * notification. NXP Semiconductors also make no representation or
 * warranty that such application will be suitable for the specified
 * use without further testing or modification.
 *                  (C) Copyright 2011 NXP Semiconductors
 *****************************************************************************/
#ifndef __CBACK_CONFIG_H__
#define __CBACK_CONFIG_H__

/* function names for the callback functions on the */
extern void kbd1Action(KeypadIdType kbdNum);
extern void kbd2Action(KeypadIdType kbdNum);
extern void kbd3Action(KeypadIdType kbdNum);
extern void kbd4Action(KeypadIdType kbdNum);
extern void kbd5Action(KeypadIdType kbdNum);
extern void kbd6Action(KeypadIdType kbdNum);
extern void kbd7Action(KeypadIdType kbdNum);
extern void kbd8Action(KeypadIdType kbdNum);

/* used to perform an action after a keystroke has been detected */
typedef void (*CallbackFctType)(KeypadIdType kbdNum);

/* table of callback functions for key pad processing */
extern const CallbackFctType KeypadAction[NUM_KPAD];

#endif   /* __CBACK_CONFIG_H__ */
