/*********************************************************************************
*
* 	io.c
*
*	I/O set up for MCB2300 and Tone Generator application
*
*   Copyright(C) 2007, NXP Semiconductor
*   All rights reserved.
*
**********************************************************************************/


#include "LPC17xx.h"



void io_init (void)
{

//  PINCON->PINSEL0 = 0x00000000;		
  PINCON->PINSEL1 = 0x00200000;			// enable DAC t0 P0.26
  PINCON->PINSEL3 = 0x000C3000;			// MAT1.0, MAT1.1 (pins 51 and 56 on LPC2378)
  PINCON->PINSEL4 = 0x0000000A;			//  TXD1 and RXD1 to P2.0/P2.1
  PINCON->PINSEL10 = 0;
  GPIO2->FIODIR = 0x0000007C;			// LED P2.2 through P2.6
  GPIO2->FIOMASK = 0x00000000;			
}



