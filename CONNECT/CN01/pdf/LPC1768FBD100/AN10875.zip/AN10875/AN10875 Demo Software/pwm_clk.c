 /****************************************************************
 *		pwm_clk.c   -  Tone Sequencers
 *
 *
 *
 *
 *
 ****************************************************************/
#include <LPC23xx.H>


#define TCR_CNT_EN		0x00000001
#define TCR_RESET		0x00000002


void InitT1PWM(void)
{
	T1TCR = TCR_RESET;	// Counter Reset // 
	T1MCR = 0x02;			// Set MRO to reset on Match
	T1MR0 = 11;				// toggle frequency = 12Mhz/2*(T1MR0+1) = 500 khz 
							// (for SC filter clock)
	T1EMR = 0x31;			// Toggle MR0 on match (pin 51 on LPC2378)
	T1TCR = TCR_CNT_EN;		// Enable counter 	
}


