extern void init_serial (void);            /* Initialize Serial Interface     */
extern char putchar (int ch);              /* Write character to Serial Port  */
extern char  getchar (void);                /* Read character from Serial Port */
extern void puthex (char hex);
extern void put_long_hex (long value);
extern void putstr (char *p);
extern void serial_1 (void) __irq;			   // ISR

extern unsigned char rcv_buf;




