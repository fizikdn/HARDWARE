 /****************************************************************
 *		seqencer.h   -  Tone Sequencer header file
 *
 *
 *
 *
 *
 ****************************************************************/

  extern void HighPriSequence (unsigned char alarm_type);
  extern void MedPriSequence (unsigned char alarm_type);
  extern void LowPriSequence (unsigned char alarm_type);
  extern void TestSequence (unsigned char alarm_type);
  extern short envelope;
  extern void init_seqencer(void);

  extern unsigned char active_note;
  extern unsigned char envelope_on;	
  extern unsigned char envelope_off;

