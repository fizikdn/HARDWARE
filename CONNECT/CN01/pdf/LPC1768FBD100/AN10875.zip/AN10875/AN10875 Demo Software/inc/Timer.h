extern void wait(void);
extern void init_timer(void);
extern void tc0 (void) __irq ;

extern unsigned char note_on;
extern unsigned char note_level;
extern unsigned char alarm;
extern long sequence;

extern short mscount;
extern unsigned char envelope_off;
extern unsigned char envelope_on;

enum {GENERAL,OXYGEN,VENTILATION,CARDIOVASCULAR,TEMPERATURE,DRUG_DELIVERY,
		PERFUSION,POWER_FAIL,LOW_ALARM};
