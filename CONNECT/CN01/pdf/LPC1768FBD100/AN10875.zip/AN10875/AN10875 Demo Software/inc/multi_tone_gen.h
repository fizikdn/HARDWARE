 /****************************************************************
 *		multi_tone_gen.h   -  Multi Tone Generator header file
 *
 *
 *
 *
 *
 ****************************************************************/

extern void InitToneCoefArray(void);

extern void OutputTones(unsigned char note, unsigned char level);

extern unsigned char ToneWeights[5];

enum {C4,D4,E4,F4,Fsharp4,G4,A4,B4,C5};


