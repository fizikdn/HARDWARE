extern void VIC_init (void);

#define TIMER0_UART1_ADC0 0x00040090   // Timer 0, UART1, ADC0
#define TIMER0_UART1 0x00000090   // Timer 0, UART1, ADC0
#define INTERRUPTS 0xFFFFFFFF   // Timer 0, UART1, ADC0 0x00040090   // Timer 0, UART1, ADC0
