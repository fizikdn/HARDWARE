 /****************************************************************
 *		command.h -  exports from commnds.c
 *
 *
 *
 *
 *
 ****************************************************************/

extern void Menu(unsigned char rcv_byte);
extern void ResetMenu(void);
extern void CommandInit(void);

extern unsigned char priority;
