application example  
-------------------------

This application start project is intended to support the following
MCUs from NXP:
all MCUs belonging to LPC176x Family

MCU: 				LPC1768
Core:				ARM Cortex-M3
Compiler/Linker:	GNU toolchain

The application is based on the memory model which is manifested
in the linker command file "main.ld" of the project. You will find it
in the workspace under "Other files".

If your controller supports a different memory layout (view below), adjust that in the 
linker command file.

memory model of the application 

FlashBase:	0x0000.0000
FlashSize:	512 Kbytes
RAMBase:	0x1000.0000
RAMSize:	32 Kbytes		(another 32Kbytes are available at a different location)

+---------------------------+0xffffffff
|                		 	|
|                			|
|                 			|
+---------------------------+<-- _stacktop (0x20007FFC)
| 							|
| 		STACK 				|<-- currrent stack-pointer (decreasing)
|                 			|
|							|
| . . . . . . . . . . . . .	|                			|  
| 							|
|  		HEAP (0x2000)		|<-- current heap-pointer (increasing)
| . . . . . . . . . . . . .	|	
|							|				
| initialized data (consts) |
| . . . . . . . . . . . . .	|<-- (0x10002000) 
|							|		
|   uninitialized data		|
+---------------------------+<-- _edata (0x10000000)
|                 			|
|                 			|
|                 			|			
|       CODE			 	|
|                 			|
|							|
+---------------------------+ 0x000000000
	

	

