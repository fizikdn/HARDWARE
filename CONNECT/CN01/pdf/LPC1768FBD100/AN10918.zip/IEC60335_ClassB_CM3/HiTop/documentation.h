/*!
	\mainpage

	This documentation describes the IEC60335 Class B library for the NXP LPC1000 microcontroller family.

	\section main1 The Library Files
	All library contents are collected in the file \a IEC60335.h.
	\subsection main1sub1 Usage examples
	In the file \a main.c are bundled some usage examples.

*/