#ifndef __CB_types_
#define __CB_types_

typedef signed char			INT8;
typedef unsigned char		UINT8;

typedef signed short		INT16;
typedef unsigned short		UINT16;

typedef signed int			INT32;
typedef unsigned int		UINT32;

typedef signed long long	INT64;
typedef unsigned long long	UINT64;

typedef	float				FLOAT32;
typedef	double				FLOAT64;

typedef unsigned char		BOOL;

#define NULL				0
#define FALSE				0
#define TRUE				1

#define MIN(a,b)				((a<b)?a:b)
#define MAX(a,b)				((a>b)?a:b)
#define CUT(a,b,c)				(MAX(a,MIN(b,c)))
#define ifIsInRange(a,b,c)		((CUT(a,b,c) == b)?TRUE:FALSE)

#endif
