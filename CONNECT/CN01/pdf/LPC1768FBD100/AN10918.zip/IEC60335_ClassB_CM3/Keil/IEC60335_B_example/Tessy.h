#ifdef TESSY
    extern void TS_TessyDummy(void* TS_var);
#endif

#ifdef TESSY
/* Tessy is always used for testing code coverage of non executable code, */
/* e.g. for destroying the contents of the memory cells om RAM test */

#define TESSY_TESTCODE( x ) TS_TessyDummy( (x)) ;
#else
/* No executable code is generated otherwise*/
#define TESSY_TESTCODE( x )              /* Tessy Dummy  */ ;
#endif
