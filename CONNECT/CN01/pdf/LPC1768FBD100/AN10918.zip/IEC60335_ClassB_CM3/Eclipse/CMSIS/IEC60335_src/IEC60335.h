#ifndef __IEC60335_
#define __IEC60335_

typedef enum tag_testResult
{
	IEC60335_testFailed = 0,
	IEC60335_testPassed = 1
} type_testResult;

#include "IEC60335_typedefs.h"
#include "IEC60335_ErrorCodes.h"

#include "IEC60335_B_SecureDataStorage.h"
#include "IEC60335_B_Interrupts.h"

#include "IEC60335_B_CPUregTests.h"
#include "IEC60335_B_RAMTest.h"
#include "IEC60335_B_FLASHTest.h"

#endif
